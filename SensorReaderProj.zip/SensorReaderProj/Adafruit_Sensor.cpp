#include "Adafruit_Sensor.h"

void Adafruit_Sensor::constructor() {}
